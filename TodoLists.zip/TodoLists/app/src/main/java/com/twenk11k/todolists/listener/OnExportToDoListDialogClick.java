package com.twenk11k.todolists.listener;

public interface OnExportToDoListDialogClick {

    void onSendViaEmailBtnClick();
    void onSaveToStorageBtnClick();

}
