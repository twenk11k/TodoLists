package com.twenk11k.todolists.di.injector;

public interface Injectable {
}
