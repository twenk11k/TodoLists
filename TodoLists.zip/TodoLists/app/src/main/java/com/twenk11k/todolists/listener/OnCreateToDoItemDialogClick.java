package com.twenk11k.todolists.listener;

public interface OnCreateToDoItemDialogClick {
    void onCreateBtnClick(String name, String description, String deadline, String createDate);

}
