package com.twenk11k.todolists.listener;

public interface OnDeleteToDoListDialogClick {
    void onDeleteBtnClick();

}
