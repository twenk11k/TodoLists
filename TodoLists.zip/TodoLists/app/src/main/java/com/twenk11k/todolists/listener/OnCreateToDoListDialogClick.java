package com.twenk11k.todolists.listener;

public interface OnCreateToDoListDialogClick {
    void onCreateBtnClick(String name, String createDate);
}
