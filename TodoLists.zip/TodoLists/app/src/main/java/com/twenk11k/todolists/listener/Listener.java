package com.twenk11k.todolists.listener;

import android.view.View;

public interface Listener {
    void onClick(View view);
}
